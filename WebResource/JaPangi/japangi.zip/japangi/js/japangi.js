/**
 * 
 */
$.getScript("../../japangi/js/japangi.js",function(){
	database();
});
function automacine(prod){
    this.maxProd = 8; // 자판기에 전시되는 상품갯수
    this.minPrice=100; // 최소 가격
    this.maxPrice=1500; // 최대 가격
    this.myPoket=10000; // 내지갑
    this.inCoin=0; // 투입된 동전

    this.prodInfo = makeProd(this.maxProd, prodKind, this.minPrice, this.maxPrice); // 음료수 객체 생성
}
